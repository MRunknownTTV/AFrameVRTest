
let DancingMouth = document.getElementById("Moving-Part").addEventListener("click", () => {
    if (!playing) {
        Audio.playSound()
    }
    else {
         audio.stopSound();
      }
      playing = !playing;
      });

    



